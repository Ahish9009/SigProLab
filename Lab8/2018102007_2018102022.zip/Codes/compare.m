function X = compare()
    itr = 10;
    timesradix = zeros(itr);
    timesdirect = zeros(itr);
    timesfft = zeros(itr);
    Nmatrix = zeros(itr);
    
    % For 'itr' powers of 2
    for i=1:itr
        N = 2.^i;
        Nmatrix(i) = N;
        
        % Calculating time taken for Direct DFT
        tic;            
        for j = 1:10
            % Generating some random input vector of length N
            x = rand(1, N);
            directdftX = directdft(x);
        end
        toc;
        timesdirect(i) = toc;
        
        % Calculating time taken for Radix2 DFT
        tic;            
        for j = 1:10
            % Generating some random input vector of length N
            x = rand(1, N);
            radix2fftX = radix2fft(x);
        end
        toc;
        timesradix(i) = toc;
        
        % Calculating time taken for Inbuilt FFT function
        tic;
        for j = 1:10
            % Generating some random input vector of length N
            x = rand(1, N);
            fftX = fft(x);
        end
        toc;
        timesfft(i) = toc;
        
        % Plotting the results for comparision
        plot(1:itr, timesfft, 'ro:', 1:itr, timesdirect, 'bo:', 1:itr, timesradix, 'ko:');
        legend("FFT-red", "DirectDFT-blue", "Radix2FFT-black");
        title("Comparision of time taken with N = restricted to powers of two");
        xlabel("Powers of 2");
        ylabel("Time taken"); 
    end
    
    % For values of N not restricted to powers of two
    timesdirect2 = zeros(50);
    timesfft2 = zeros(50);
    Nmatrix2 = zeros(50);
    for i=1:50
        N = i;
        Nmatrix2(i) = N;
        
        % For direct DFT
        tic;            
        for j = 1:10
            % Generating some random input vector of length N
            x = rand(1, N);
            directdftX = directdft(x);
        end
        toc;
        timesdirect2(i) = toc;
        
        % For inbuilt FFT function
        tic;
        for j = 1:10
            % Generating some random input vector of length N
            x = rand(1, N);
            fftX = fft(x);
        end
        toc;
        timesfft2(i) = toc;
        
        % Plotting the results for comparision
        plot(1:50, timesfft2, 'ro:', 1:50, timesdirect2, 'bo:');
        legend("FFT-red", "DirectDFT-blue");
        title("Comparision of time taken with N = not restricted to powers of two");
        xlabel("N");
        ylabel("Time taken");
    end
end