function X = directdft(x)
    % x should be a length-N column vector
    N = length(x);
    x = transpose(x);

    % create N x N DFT matrix
    F = zeros(N,N);
    for i = 1:N
        for j = 1:N
            F(i,j) = exp(2*pi*-1i*(i-1)*(j-1)/N);
        end
    end

    % compute w using a matrix-vector product
    X = F*x;
    
    % Plot commented out since it is being plotted
    % through the script 'rectpulsedft.m'
    % ------------------------------------- %
    % subplot(2,1,1);
    % plot(1:N, x, 'o:');
    % title("Input Vector");
    % xlabel("n");
    % ylabel("x");
    % subplot(2,1,2);
    % plot(1:N, abs(X), 'o:');
    % title("Absolute value of DFT");
    % xlabel("n");
    % ylabel("abs(X)");
end