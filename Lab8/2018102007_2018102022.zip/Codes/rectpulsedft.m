function y = rectpulsedft()
	L = 2;
    for N = (L+1):(L+4) 
        x = [ones(1, L),zeros(1, N-L)];
        X = directdft(x);
        
        % Plotting x vs n
        subplot(2, 4, N-L);
        plot(1:N, x, 'o:');
        title("Rectangular Pulse (N="+N+", L="+L+")");
        xlabel("n");
        ylabel("Magnitude");
        
        % Plottinh abs(X) vs n
        subplot(2, 4, N-L+4);
        plot(1:N, abs(X), 'o:');
        title("DFT of the rectangular pulse (N="+N+", L="+L+")");
        xlabel("n");
        ylabel("Magnitude");
    end
end